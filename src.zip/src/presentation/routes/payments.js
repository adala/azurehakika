const express = require('express');
const router = express.Router();
const { requireAuth, authenticateToken } = require('../middleware/auth');

module.exports = (paymentController) => {
    router.get('/add-funds', requireAuth, paymentController.showAddFunds.bind(paymentController));
    router.get('/wallet', authenticateToken, paymentController.showWallet.bind(paymentController));
    router.get('/balance', requireAuth, paymentController.getBalance.bind(paymentController));
    
    return router; 
};