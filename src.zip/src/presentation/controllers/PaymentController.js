class PaymentController {
    constructor(
        addFundsUseCase,
        getWalletBalanceUseCase
    ) {
        this.addFunds = addFundsUseCase;
        this.getWalletBalance = getWalletBalanceUseCase;
    }

    async initializePayment(req, res) {
        try {
            const { amount, paymentMethod, currency } = req.body;
            const userId = req.session.user.id;

            const result = await this.addFunds.execute(
                userId,
                parseFloat(amount),
                paymentMethod,
                currency
            );
 
            res.json({
                success: true,
                data: result
            });
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async getBalance(req, res) {
        try {
            
            const userId = req.user.id;

            const result = await this.getWalletBalance.execute(userId);
          
            res.status(200).json({
                success: true,
                data: result
            });
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async confirmPayment(req, res) {
        try {
            const { paymentReference } = req.body;
            const userId = req.user.userId;

            const result = await this.addFunds.confirmPayment(userId, paymentReference);

            res.json({
                success: true,
                data: result
            });
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async handleWebhook(req, res) {
        try {
            // This would handle payment provider webhooks
            const { type, data } = req.body;

            // Process webhook based on type
            switch (type) {
                case 'payment.succeeded':
                    // Update wallet balance
                    break;
                case 'payment.failed':
                    // Handle failed payment
                    break;
            }

            res.json({ received: true });
        } catch (error) {
            console.error('Webhook error:', error);
            res.status(400).json({ error: 'Webhook processing failed' });
        }
    }

    async getPaymentStatus(req, res) {
        try {
            const { reference } = req.params;
            const userId = req.user.userId;

            // Check payment status from your payment service
            const status = await this.paymentService.getPaymentStatus(reference, userId);

            res.json({
                success: true,
                data: status
            });
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    async confirmPin(req, res) {
        try {
            const { paymentReference, pin } = req.body;
            const userId = req.user.userId;

            const result = await this.paymentService.confirmPin(paymentReference, pin, userId);

            res.json({
                success: true,
                data: result
            });
        } catch (error) {
            res.status(400).json({
                success: false,
                message: error.message
            });
        }
    }

    // Render methods
    showWallet(req, res) {
        res.render('dashboard/wallet', {
            title: 'Wallet - AcademicVerify',
            user: req.session.user
        });
    }

    showAddFunds(req, res) {
        res.render('money/add-funds', {
            title: 'Add Funds - AcademicVerify',
            user: req.session.user
        });
    }

    showPaymentProcessing(req, res) {
        res.render('money/payment-processing', {
            title: 'Processing Payment - AcademicVerify',
            user: req.session.user
        });
    }

    showPaymentPin(req, res) {
        const { paymentReference, paymentMethod } = req.query;
        res.render('money/payment-pin', {
            title: 'Confirm Payment - AcademicVerify',
            user: req.session.user,
            paymentReference,
            paymentMethod
        });
    }

    showPaymentStatus(req, res) {
        const { status, message, reference } = req.query;
        res.render('dashboard/payment-status', {
            title: 'Payment Status - AcademicVerify',
            user: req.session.user,
            status,
            message,
            reference
        });
    }
}

module.exports = PaymentController;