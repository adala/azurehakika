class IPaymentService {
    async initializePayment(amount, currency, paymentMethod, metadata) {
        throw new Error('Method not implemented');
    }

    async verifyPayment(reference) {
        throw new Error('Method not implemented');
    }

    async processWebhook(payload) {
        throw new Error('Method not implemented');
    }
}

module.exports = IPaymentService;