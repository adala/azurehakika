class InstitutionResponseRepository {
    async create(response) { throw new Error('Not implemented'); }
    async findByVerificationId(verificationId) { throw new Error('Not implemented'); }
    async update(id, updates) { throw new Error('Not implemented'); }
    async findByStatus(status) { throw new Error('Not implemented'); }
    async findByInstitutionId(institutionId) { throw new Error('Not implemented'); }
}

module.exports = InstitutionResponseRepository;