class IPDFService {
    async generateVerificationReport(verificationData) { throw new Error('Method not implemented'); }
    async generateBulkVerificationReport(bulkVerificationData) { throw new Error('Method not implemented'); }
    async generateTransactionReceipt(transactionData) { throw new Error('Method not implemented'); }
    async generateAnalyticsReport(analyticsData, period) { throw new Error('Method not implemented'); }
}

module.exports = IPDFService;