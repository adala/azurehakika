class ActivateTeamMember {
    constructor(teamMemberRepository) {
        this.teamMemberRepository = teamMemberRepository;
    }

    async execute(invitationId, userId) {
        const teamMember = await this.teamMemberRepository.activateMember(invitationId, userId);
        return teamMember.toJSON();
    }
}

module.exports = ActivateTeamMember;