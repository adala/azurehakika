class AddFunds {
    constructor(
        walletRepository,
        transactionRepository,
        paymentService,
        emailService
    ) {
        this.walletRepository = walletRepository;
        this.transactionRepository = transactionRepository;
        this.paymentService = paymentService;
        this.emailService = emailService;
    }

    async execute(userId, amount, paymentMethod, currency = 'USD') {
        if (amount <= 0) {
            throw new Error('Amount must be greater than zero');
        }

        // Create transaction record
        const reference = `TOPUP${Date.now()}${Math.random().toString(36).substr(2, 9)}`;

        const transaction = await this.transactionRepository.create({
            userId,
            type: 'topup',
            amount,
            currency,
            reference,
            status: 'pending',
            description: `Wallet topup via ${paymentMethod}`,
            metadata: { paymentMethod }
        });

        // Initialize payment
        const paymentResult = await this.paymentService.initializePayment(
            amount,
            currency, 
            paymentMethod,
            {
                userId,
                transactionId: transaction.id,
                purpose: 'wallet_topup'
            }
        );

        if (!paymentResult.success) {
            await this.transactionRepository.updateStatus(reference, 'failed');
            throw new Error('Payment initialization failed');
        }

        return {
            paymentReference: paymentResult.reference,
            paymentUrl: paymentResult.paymentUrl,
            amount,
            currency,
            transactionId: transaction.id
        };
    }

    async confirmPayment(userId, paymentReference) {
        // Verify payment
        const verificationResult = await this.paymentService.verifyPayment(paymentReference);

        if (!verificationResult.success) {
            await this.transactionRepository.updateStatus(paymentReference, 'failed');
            throw new Error(`Payment failed: ${verificationResult.message}`);
        }

        // Update transaction status
        const transaction = await this.transactionRepository.updateStatus(
            paymentReference,
            'completed'
        );

        // Add funds to wallet
        const wallet = await this.walletRepository.updateBalance(userId, transaction.amount);

        // Send confirmation email
        await this.emailService.sendPaymentConfirmation(userId, transaction.amount);

        return {
            success: true,
            amount: transaction.amount,
            newBalance: wallet.balance,
            message: 'Funds added successfully'
        };
    }
}

module.exports = AddFunds;